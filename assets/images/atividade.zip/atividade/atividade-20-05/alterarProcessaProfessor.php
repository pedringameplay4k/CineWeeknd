<?php require_once "ClassProfessor.php";  ?>
<?php require_once "ClassProfessorDAO.php";  ?>
<?php
   
    $id = $_GET['id'];
    $nome = $_GET['nome'];
    $email = $_GET['email'];
    $salario = $_GET['salario'];
    $nivel = $_GET['nivel'];       
    $ClassProfessorDAO = new ClassProfessorDAO();
    $novoProfessor = new ClassProfessor();
    $novoProfessor -> setId($id);
    $novoProfessor -> setNome($nome);
    $novoProfessor -> setEmail($email);
    $novoProfessor -> setSalario($salario);
    $novoProfessor -> setNivel($nivel);  
    $array=$ClassProfessorDAO->alteraProfessor($novoProfessor);

    if($array==true) {
        header('Location:listarProfessor.php');    
         } else {
        echo "Erro";
    }
    
?>                 