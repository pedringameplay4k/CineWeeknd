<?php require_once "ClassDisciplina.php";  ?>
<?php require_once "ClassDisciplinaDAO.php";  ?>
<?php


$ClassDisciplinaDAO = new ClassDisciplinaDAO();
$array=$ClassDisciplinaDAO->listarDisciplina();

echo "<center><h3>RESULTADO </h3></center>";
	echo "<center>";
    echo "<table border=2>";
    echo "  <tr>";
    echo "      <th>  Id     </th>";
    echo "      <th>  Nome   </th>";
	echo "      <th>  Requisito</th>";
	echo "      <th>  Carga Horaria</th>";
    echo "      <th>  Excluir</th>";
    echo "      <th>  Alterar</th>";
    echo "  </tr>";
	echo "</center>";
    foreach ($array as $array) {
        echo "<tr>";
        echo "<td>" . $array['id'] . "</td>";
        echo "<td>" . $array['nome'] . "</td>";
        echo "<td>" . $array['requisito'] . "</td>";
        echo "<td>" . $array['carga_horaria'] . "</td>";
        echo "<td>";
    ?>
    <form action="excluirDisciplina.php" method="GET">
        <input type=hidden name=id
               value=<?php echo $array['id']; ?> >
               
        <button style='background:transparent; border:none; margin-left:8px; margin-top:12px; cursor:pointer;'>
            <img src="img/excluir.png" alt="excluir"
                 width='20px' height='20'>
         </button>    
    </form>
    <?php 
    echo "</td>";
    echo "<td>";
    ?>  
     <form action="alterarDisciplina.php" method="GET">
         <input type=hidden name=id
                value=<?php echo $array['id']; ?> >

         <input type=hidden name=nome
                value=<?php echo $array['nome']; ?> >

         <input type=hidden name=requisito
                value=<?php echo $array['requisito']; ?> >

         <input type=hidden name=carga_horaria
                value=<?php echo $array['carga_horaria']; ?> >
                
        <button style='background:transparent; border:none; margin-left:8px; margin-top:12px; cursor:pointer;'>
            <img src="img/alterar.png" alt="alterar"
                 width='20px' height='20'>
         </button>    
    </form>
    <?php 
    echo "</td>";
    echo "</tr>";
}  
?>