<?php require_once "ClassDisciplina.php";  ?>
<?php require_once "ClassDisciplinaDAO.php";  ?>
<?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

           
    $novoDisciplina = new ClassDisciplina();
    $novoDisciplina->setId($id); 
    $ClassDisciplinaDAO = new ClassDisciplinaDAO();
    $array=$ClassDisciplinaDAO->excluirDisciplina($novoDisciplina);

    if($array==true) { 
        header('Location:listarDisciplina.php');    
    }
    }

    
?>