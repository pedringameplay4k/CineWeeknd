<?php require_once "ClassDisciplina.php";  ?>
<?php require_once "ClassDisciplinaDAO.php";  ?>
<?php
   
    $id = $_GET['id'];
    $nome = $_GET['nome'];
    $requisito = $_GET['requisito'];
    $carga_horaria = $_GET['carga_horaria'];     
    $ClassDisciplinaDAO = new ClassDisciplinaDAO();
    $novoDisciplina = new ClassDisciplina();
    $novoDisciplina->setId($id);
    $novoDisciplina->setNome($nome);
    $novoDisciplina->setRequisito($requisito);
    $novoDisciplina->setCarga_horaria($carga_horaria);
?>                 

    <body>
        <center>
            <form action="alterarProcessaDisciplina.php" method="GET">
                <h1>ALTERAR DADOS</h1>
                    Id: <br> <input type="text" name="id"readonly="true"
                    value=<?php echo $novoDisciplina->getId($id); ?> > <br>

                    Nome: <br> <input type="text" name="nome"
                    value=<?php echo $novoDisciplina->getNome($nome); ?> > <br>

                    Requisito: <br> <input type="text" name="requisito"
                    value=<?php echo $novoDisciplina->getRequisito($requisito); ?> > <br>

                    Carga horária: <br> <input type="text" name="carga_horaria"
                    value=<?php echo $novoDisciplina->getCarga_horaria($carga_horaria); ?> > <br>
                    <br><br>

                    <button type="submit" class="btn btn-primary">ALTERAR</button>
            </form>
        </center>
    </body>