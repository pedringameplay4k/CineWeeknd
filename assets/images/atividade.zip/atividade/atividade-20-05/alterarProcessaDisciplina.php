<?php require_once "ClassDisciplina.php";  ?>
<?php require_once "ClassDisciplinaDAO.php";  ?>
<?php
   
    $id = $_GET['id'];
    $nome = $_GET['nome'];
    $requisito = $_GET['requisito'];
    $carga_horaria = $_GET['carga_horaria'];   
    $ClassDisciplinaDAO = new ClassDisciplinaDAO();
    $novoDisciplina = new ClassDisciplina();
    $novoDisciplina -> setId($id);
    $novoDisciplina -> setNome($nome);
    $novoDisciplina -> setRequisito($requisito);
    $novoDisciplina -> setCarga_horaria($carga_horaria); 
    $array=$ClassDisciplinaDAO->alteraDisciplina($novoDisciplina);
    
    if($array==true) {
        header('Location:listarDisciplina.php');    
         } else {
        echo "Erro";
    }
    
?>                 