<?php require_once "ClassProfessor.php";  ?>
<?php require_once "ClassProfessorDAO.php";  ?>
<?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        
    $novoProfessor = new ClassProfessor();
    $novoProfessor->setId($id); 
    $ClassProfessorDAO = new ClassProfessorDAO();
    $array=$ClassProfessorDAO->excluirProfessor($novoProfessor);

    if($array==true) {
        header('Location:listarProfessor.php');    
    }
    }



?>