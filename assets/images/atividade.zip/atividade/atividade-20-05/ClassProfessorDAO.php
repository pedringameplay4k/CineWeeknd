<?php require_once "Conexao.php";  ?>
<?php
    class ClassProfessorDAO {
        public function cadastrarProfessor($novoProfessor) {
         try {
            $pdo = Conexao::getInstance();
            $sql = "insert into professores(nome,email,salario,nivel)
                    values (?,?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $novoProfessor->getNome());
            $stmt->bindValue(2, $novoProfessor->getEmail());
            $stmt->bindValue(3, $novoProfessor->getSalario());
            $stmt->bindValue(4, $novoProfessor->getNivel());
            $stmt->execute();
            
            echo "<center><h1>Cadastro realizado com sucesso!</h1><center><br>";
            echo "<a href='listarProfessor.php'>Listar</a>";
            
        } catch (PDOException $erro) {
                echo $erro->getMessage();
        }
    }

    public function listarProfessor() {
        try {
            $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM professores";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            return $stmt->fetchALL();

        } catch (PDOException $erro) {
            echo $erro->getMessage();
        }

    }

    public function excluirProfessor($novoProfessor) {
        try {
            $pdo = Conexao::getInstance();
            $sql = "delete from professores
                    where id =:id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $novoProfessor->getId());
            $stmt->execute();
            return true;
            

        } catch (PDOException $erro) {
            echo $erro->getMessage();
        }
    }

    public function alteraProfessor($novoProfessor) {
        try {
            $pdo = Conexao::getInstance();
            $sql = "update professores 
                    set nome =:nome, email =:email, salario =:salario, nivel =:nivel
                    where id =:id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':nome', $novoProfessor->getNome());
            $stmt->bindValue(':email', $novoProfessor->getEmail());
            $stmt->bindValue(':salario', $novoProfessor->getSalario());
            $stmt->bindValue(':nivel', $novoProfessor->getNivel());
            $stmt->bindValue(':id', $novoProfessor->getId());
            $stmt->execute();
            return true;
            

        } catch (PDOException $erro) {
            echo $erro->getMessage();
        }
    }
}
?>