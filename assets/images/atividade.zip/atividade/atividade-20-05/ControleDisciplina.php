<?php require_once "ClassDisciplina.php";  ?>
<?php require_once "ClassDisciplinaDAO.php";  ?>
<?php
    $nome = $_POST['nome'];  
    $requisito = $_POST['requisito'];
    $carga_horaria = $_POST['carga_horaria'];
    $novoDisciplina = new ClassDisciplina();
    $novoDisciplina->setNome($nome);
    $novoDisciplina->setRequisito($requisito);
    $novoDisciplina->setCarga_horaria($carga_horaria);   
    $ClassDisciplinaDAO = new ClassDisciplinaDAO();
    $ClassDisciplinaDAO->cadastrarDisciplina($novoDisciplina);

?>